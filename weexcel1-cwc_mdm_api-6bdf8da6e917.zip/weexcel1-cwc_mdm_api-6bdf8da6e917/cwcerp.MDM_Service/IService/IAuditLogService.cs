﻿using cwcerp.Mdm_Models.Response;

namespace cwcerp.Mdm_Service.IService
{
    public interface IAuditLogService 
    {
        Response GetAuditLogs();
    }
}
