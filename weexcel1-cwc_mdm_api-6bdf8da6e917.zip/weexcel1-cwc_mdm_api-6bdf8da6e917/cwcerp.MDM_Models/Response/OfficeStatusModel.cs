﻿namespace cwcerp.MDM_Models.Response
{
    public class WOfficeStatus
    {
        public int? OfficeId { get; set; }
        public int? OfficeTypeId { get; set; }
        public int? ProcessId { get; set; }
        public int? StatusId { get; set; }
        public string? Reason { get; set; }
        public int? StepId { get; set; }
    }
}

