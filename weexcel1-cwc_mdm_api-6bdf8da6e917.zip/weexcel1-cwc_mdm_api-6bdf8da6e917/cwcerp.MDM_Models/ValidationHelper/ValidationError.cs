﻿namespace ValidationHelper
{
    public class ValidationError
    {
    }
}